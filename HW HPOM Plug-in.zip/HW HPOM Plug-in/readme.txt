****************************************************************************
HPE Operations Manager, Monitoring Management Plugin Pack for Huawei Device
****************************************************************************

I. General Information

    Name:     Management Plugin Pack for Huawei Device
    Category: Monitoring
    Version:  1.0


II. Description

    This management package provides SNMP trap monitoring solution over certian Huawei Server devices. This solution is compatible with HP OMW 9.0/OML 9.22/OMi 10.11
	
III.Supported Device
	Huawei Blade Server: E9000
	Huawei Rack  Server: RH1288 V3, RH2288H V2, RH2288 V3, RH2288H V3
	Huawei High-density Server:  X6000, X6800


IV. Additional Resources

    For more information consult User Guide. https://github.com/Huawei/Server_Manage_Plugin_HPOM